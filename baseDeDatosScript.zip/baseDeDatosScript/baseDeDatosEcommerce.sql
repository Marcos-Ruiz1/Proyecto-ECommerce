CREATE DATABASE eCommerce;

Create Table Usuarios(

	idUsuario int primary key auto_increment,
	nombre varchar(100) not null unique,
	email varchar(70) not null unique,
	telefono varchar(20) not null unique,
	direccion varchar(200),
    contrasena VARCHAR(15) NOT NULL
);

Create Table Pedidos(

	idPedido int primary key auto_increment,
	fechaDePedido DATETIME not null,
	cantidad DECIMAL(10, 2) not null,
	idUsuario int,
	foreign key(idUsuario) references Usuarios(idUsuario)
);

Create Table Categorias(

	idCategoria int primary key auto_increment,
	nombre varchar(50) not null
);

Create Table Productos(

	idProducto int primary key auto_increment,
	nombre varchar(100) not null,
	descripcion varchar(500),
	precio DECIMAL(10,2) not null,
	idCategoria int,
        foreign key(idCategoria) references Categorias(idCategoria)
);

Create Table ProductosPedidos(

	idProductoPedido int primary key auto_increment,
	idPedido int,
	idProducto int,
	foreign key(idPedido) references Pedidos(idPedido),
	foreign key(idProducto) references Productos(idProducto)
);


DELIMITER //

CREATE PROCEDURE ObtenerPedidosPorUsuario(IN userId INT)
BEGIN
    SELECT * FROM Pedidos WHERE idUsuario = userId;
END //

DELIMITER ;
